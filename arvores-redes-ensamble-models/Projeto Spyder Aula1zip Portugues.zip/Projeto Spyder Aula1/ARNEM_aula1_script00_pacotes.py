# -*- coding: utf-8 -*-
"""
Created on Sun Dec  8 20:51:46 2024

@author: João Mello
"""

#%% Instalar os pacotes
!pip install numpy
!pip install pandas
!pip install matplotlib
!pip install seaborn
!pip install scikit-learn